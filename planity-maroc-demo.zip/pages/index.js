export default function Home() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center">
      <h1 className="text-3xl font-bold">Bienvenue sur Planity Maroc</h1>
      <p>Réservez vos soins beauté en ligne.</p>
    </main>
  );
}